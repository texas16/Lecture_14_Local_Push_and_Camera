//
//  Cool_CameraApp.swift
//  Cool_Camera
//
//  Created by ilyas uyanik on 5/11/25.
//

import SwiftUI

@main
struct Cool_CameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
