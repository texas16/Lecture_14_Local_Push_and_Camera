//
//  Camera.swift
//  Cool_Camera
//
//  Created by ilyas uyanik on 5/11/25.
//

import SwiftUI

// mixing SwiftUI with UIKit, it is a wrapper for UIKit viewcontroller.
struct CameraView: UIViewControllerRepresentable {
    // image that we have on the main page
    @Binding var image: UIImage?
    // Used to dismiss the SwiftUI sheet when the camera is finished or cancelled
    @Environment(\.presentationMode) var presentationMode
    
    // required to connect SwiftUI with UIKit
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        
        let parent: CameraView
        
        init(_ parent: CameraView) {
            self.parent = parent
        }
        
        // extracting image from the camera and do the assignment/binding
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.originalImage] as? UIImage {
                parent.image = selectedImage
            }
            // dismiss the camera view
            parent.presentationMode.wrappedValue.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            // dismiss the camera view
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
    
    // this connects our SwiftUI to its UIKit delegate
    // required protocol method
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    // setting up and returns the camera controller
    // sourceType here -> ensure that camera opens, not photo library
    // delegate  points to Coordinator to handle user interactions
    //
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .camera
        picker.allowsEditing = true
        return picker
    }
    
    // required protocol method
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        
    }
}


// Local Notification covered, Remote Push Notification(APNS) is not covered, need to download certificates, keys from apple developer account, then you need to add into Azure Push Notication Services

// Camera - need to have apple developer account, it does not work on simulator, do not forget to ask permission via Info List, located in the Target.
