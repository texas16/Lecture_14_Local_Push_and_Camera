//
//  ContentView.swift
//  Cool_Camera
//
//  Created by ilyas uyanik on 5/11/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isShowingCamera = false
    @State private var image : UIImage?
    
    // add UI to display taken photos
    // add button to take user to device camera
    var body: some View {
        VStack(spacing: 20) {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .cornerRadius(12)
            } else {
                Text("No photo yet")
                    .foregroundStyle(.gray)
            }
            
            Button("Take Photo") {
                isShowingCamera = true
            }
            .font(.title2)
            .padding()
        }
        .sheet(isPresented: $isShowingCamera) {
            CameraView(image: $image)
        }
    }
}

#Preview {
    ContentView()
}
