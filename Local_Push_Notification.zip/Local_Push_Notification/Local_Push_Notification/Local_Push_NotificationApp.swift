//
//  Local_Push_NotificationApp.swift
//  Local_Push_Notification
//
//  Created by ilyas uyanik on 5/11/25.
//

import SwiftUI

@main
struct Local_Push_NotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
