//
//  ContentView.swift
//  Local_Push_Notification
//
//  Created by ilyas uyanik on 5/11/25.
//

import SwiftUI
// import UserNotifications

struct ContentView: View {
    @State private var reminderTitle = ""
    @State private var reminderDate: Date = Date().addingTimeInterval(60) // default is 1 minute
    @State private var notificationStatus = "Waiting for permission..."
    
    // local push notification
    // set up the reminder
    // title of the reminder
    // date and time
    // display when it would be displayed
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Reminder Details")) {
                    TextField("Enter reminder title", text: $reminderTitle)
                    DatePicker("Select time", selection: $reminderDate, displayedComponents: [.date, .hourAndMinute])
                        .environment(\.locale, Locale(identifier: "en_US"))
                }
                
                Section {
                    Button("Set Reminder") {
                        scheduleNotification()
                    }
                    .disabled(reminderTitle.isEmpty)
                }
                
                Section {
                    Text(notificationStatus)
                        .font(.footnote)
                        .foregroundStyle(.gray)
                }
            }
            .navigationTitle("Reminder Buddy")
            .onAppear() {
                requestNotificationPermission()
            }
        }
    }
    
    private func scheduleNotification() {
        let content = UNMutableNotificationContent()
        content.title = reminderTitle
        content.body = "It is time to attend iOS class: \(reminderTitle)"
        content.sound = .defaultCritical
        
        let triggerDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: reminderDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)
        
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            DispatchQueue.main.async {
                if let error = error {
                    notificationStatus = "Failed to schedule: \(error.localizedDescription)"
                } else {
                    notificationStatus = "Reminder set for \( formattedDate(reminderDate))"
                }
            }
        }
    }
    
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, error in
            DispatchQueue.main.async {}
            if let error = error {
                notificationStatus = "Error: \(error.localizedDescription)"
            } else {
                notificationStatus = granted ? "Notification allowed" : "Notification denied"
            }
        }
    }
}

#Preview {
    ContentView()
}
